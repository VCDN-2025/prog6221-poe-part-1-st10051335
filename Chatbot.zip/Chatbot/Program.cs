﻿using System;
using System.IO;
using System.Media;
using System.Threading.Tasks;

namespace Chatbot
{
    class Program
    {
        static async Task Main()
        {
            var bot = new ChatBot("Assets/greeting.wav");
            await bot.StartAsync();
        }
    }

    class ChatBot
    {
        private readonly string _audioFilePath;
        public string UserName { get; private set; }

        public ChatBot(string audioFilePath)
        {
            _audioFilePath = audioFilePath;
        }

        public async Task StartAsync()
        {
            await PlayVoiceGreetingAsync();
            DisplayAsciiArt();
            await GetUserNameAsync();
            await RunMainConversationLoopAsync();
        }

        private async Task PlayVoiceGreetingAsync()
        {
            // Fixed file extension from .wam to .wav
            if (!File.Exists(_audioFilePath))
            {
                LogError($"Audio file '{_audioFilePath}' not found.");
                return;
            }

            try
            {
                using var player = new SoundPlayer(_audioFilePath);
                await Task.Run(() => player.PlaySync());
            }
            catch (Exception ex)
            {
                LogError($"Error playing audio: {ex.Message}");
            }
        }

        private void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            string asciiPath = "Assets/ascii_logo.txt";

            if (File.Exists(asciiPath))
            {
                Console.WriteLine(File.ReadAllText(asciiPath));
            }
            else
            {
                LogError("ASCII art file not found.");
                // Fallback ASCII art if file isn't found
                Console.WriteLine(@"
  ____      _                                      _ _         
 / ___|   _| |__   ___ _ __ ___  ___  ___ _   _ __(_) |_ _   _ 
| |  | | | | '_ \ / _ \ '__/ __|/ _ \/ __| | | | '__| | __| | | |
| |__| |_| | |_) |  __/ |  \__ \  __/ (__| |_| | |  | | |_| |_| |
 \____\__, |_.__/ \___|_|  |___/\___|\___|\__,_|_|  |_|\__|\__, |
      |___/                                                |___/ 
    _                                             
   / \__      ____ _ _ __ ___ _ __   ___  ___  ___
  / _ \ \ /\ / / _` | '__/ _ \ '_ \ / _ \/ __|/ __| 
 / ___ \ V  V / (_| | | |  __/ | | |  __/\__ \\__ \ 
/_/   \_\_/\_/ \__,_|_|  \___|_| |_|\___||___/|___/
");
            }

            Console.ResetColor();
        }

        private async Task GetUserNameAsync()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
            Console.WriteLine("║  Welcome to the Cybersecurity Awareness Bot!              ║");
            Console.WriteLine("║  I'm here to help you stay safe online.                   ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
            Console.ResetColor();

            do
            {
                Console.Write("What's your name? ");
                UserName = Console.ReadLine()?.Trim();

                // Fixed the bug - was checking a string literal "UserName" instead of the variable
                if (string.IsNullOrWhiteSpace(UserName))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Please enter a valid name.");
                    Console.ResetColor();
                }
            } while (string.IsNullOrWhiteSpace(UserName));

            await TypeTextAsync($"Nice to meet you, {UserName}!");
        }

        private async Task RunMainConversationLoopAsync()
        {
            Console.WriteLine("Type 'help' for a list of commands or 'exit' to quit.");
            bool continueConversation = true;

            while (continueConversation)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write($"{UserName}> ");
                Console.ResetColor();

                var input = Console.ReadLine()?.Trim().ToLower();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Please enter a valid command.");
                    Console.ResetColor();
                    continue;
                }

                if (input == "exit" || input == "quit" || input == "bye")
                {
                    await TypeTextAsync($"Goodbye, {UserName}! Stay safe online!");
                    continueConversation = false;
                    continue;
                }

                await ProcessUserInputAsync(input);
            }
        }

        private async Task ProcessUserInputAsync(string input)
        {
            Console.Write("Processing");
            for (int i = 0; i < 3; i++)
            {
                Console.Write(".");
                await Task.Delay(250);
            }
            Console.WriteLine();

            // Improved with more flexible topic recognition using Contains
            if (input == "help")
            {
                DisplayHelp();
            }
            else if (input.Contains("password"))
            {
                await TypeTextAsync($"🔐 {UserName}, here's a password tip: Use strong and unique passwords with a mix of letters, numbers, and symbols. Never reuse passwords across different accounts.");
            }
            else if (input.Contains("phishing"))
            {
                await TypeTextAsync($"🎣 {UserName}, be cautious of emails asking for personal info or urgent actions. Always verify the sender and don't click suspicious links.");
            }
            else if (input.Contains("browsing") || input.Contains("internet"))
            {
                await TypeTextAsync($"🌐 {UserName}, always use secure websites (https) and avoid downloading unknown files. Keep your browser and antivirus updated.");
            }
            else if (input.Contains("social") || input.Contains("engineering"))
            {
                await TypeTextAsync($"🕵️ Social engineering is manipulation to gain unauthorized access. Be wary of unsolicited contacts and unusual requests, {UserName}.");
            }
            else if (input.Contains("mobile") || input.Contains("phone"))
            {
                await TypeTextAsync($"📱 {UserName}, protect your mobile devices by using strong PINs, installing apps only from official stores, and keeping your software updated.");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"I didn't understand that. Try 'help' for a list of commands, {UserName}.");
                Console.ResetColor();
            }
        }

        private void DisplayHelp()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("╔═══════════════════════════════════════════════════════════╗");
            Console.WriteLine("║  Available commands and topics:                           ║");
            Console.WriteLine("║  - help         : Show this help message                  ║");
            Console.WriteLine("║  - password     : Learn about safe password practices     ║");
            Console.WriteLine("║  - phishing     : Learn about phishing scams              ║");
            Console.WriteLine("║  - browsing     : Learn safe internet browsing tips       ║");
            Console.WriteLine("║  - social       : Learn about social engineering          ║");
            Console.WriteLine("║  - mobile       : Mobile device security tips            ║");
            Console.WriteLine("║  - exit/quit    : Quit the chatbot                        ║");
            Console.WriteLine("╚═══════════════════════════════════════════════════════════╝");
            Console.ResetColor();
        }

        private async Task TypeTextAsync(string text, int delay = 20)
        {
            foreach (var c in text)
            {
                Console.Write(c);
                await Task.Delay(delay);
            }
            Console.WriteLine();
        }

        private void LogError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"[Error] {message}");
            Console.ResetColor();
        }
    }
}

