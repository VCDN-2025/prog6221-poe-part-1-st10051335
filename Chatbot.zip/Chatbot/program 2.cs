using System;
using System.IO;
using System.Media;
using System.Threading.Tasks;

namespace Chatbot
{
    internal class Program
    {
        private static async Task Main(string[] args)
        {
            var bot = new ChatBot("");
            await bot.StartAsync();
        }
    }

    class ChatBot
    {
        private readonly string _audioFilePath;

        public string UserName { get; private set; }

        public ChatBot(string audioFilePath)
        {
            _audioFilePath = audioFilePath;
        }

        public async Task StartAsync()
        {
            await PlayVoiceGreetingAsync();
            DisplayAsciiArt();
            GetUserName();
            await RunMainConversationLoopAsync();
        }

        private async Task PlayVoiceGreetingAsync()
        {
            if (!File.Exists(_audioFilePath))
            {
                LogError($"Audio file '{_audioFilePath}' not found.");
                return;
            }

            try
            {
                using var player = new SoundPlayer(_audioFilePath);
                await Task.Run(() => player.PlaySync());
            }
            catch (Exception ex)
            {
                LogError($"Error playing audio: {ex.Message}");
            }
        }

        private void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(File.ReadAllText("Assets/ascii_logo.txt"));
            Console.ResetColor();
        }

        private void GetUserName()
        {
            Console.WriteLine("Welcome! What's your name?");
            do
            {
                UserName = Console.ReadLine()?.Trim();
                if (string.IsNullOrWhiteSpace(UserName))
                {
                    Console.WriteLine("Please enter a valid name.");
                }
            } while (string.IsNullOrWhiteSpace(UserName));
        }

        private async Task RunMainConversationLoopAsync()
        {
            Console.WriteLine("Type 'help' for a list of commands or 'exit' to quit.");
            while (true)
            {
                Console.Write($"{UserName}> ");
                var input = Console.ReadLine()?.Trim().ToLower();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Please enter a valid command.");
                    continue;
                }

                if (input == "exit")
                {
                    Console.WriteLine("Goodbye!");
                    break;
                }

                await ProcessUserInputAsync(input);
            }
        }

        private async Task ProcessUserInputAsync(string input)
        {
            Console.WriteLine("Processing...");
            await Task.Delay(500); // Simulate thinking

            if (input.Contains("help"))
            {
                DisplayHelp();
            }
            else
            {
                Console.WriteLine("I didn't understand that. Try 'help' for a list of commands.");
            }
        }

        private void DisplayHelp()
        {
            Console.WriteLine("Available commands:");
            Console.WriteLine("- help: Show this help message");
            Console.WriteLine("- exit: Quit the chatbot");
        }

        private void LogError(string message)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(message);
            Console.ResetColor();
        }
    }
}
